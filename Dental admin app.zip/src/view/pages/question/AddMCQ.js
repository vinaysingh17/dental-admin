import { useState, useEffect } from "react";
import {
  Container,
  makeStyles,
  MenuItem,
  Paper,
  TextField,
  Typography,
  styled,
  Button,
  RadioGroup,
  FormLabel as MuiFormLabel,
  FormControlLabel,
  Radio,
  FormControl,
  Box,
  Tooltip,
  Checkbox,
  CircularProgress,
} from "@material-ui/core";
import DraftEditor from "../../component/Editor";
import "react-draft-wysiwyg/dist/react-draft-wysiwyg.css";
import { Formik } from "formik";
import * as yup from "yup";
import SubjectAutocomplete from "../subject/SubjectAutocomplete";
import TopicAutocomplete from "../topic/TopicAutocomplete";
import SubTopicAutocomplete from "../subTopic/SubTopicAutocomplete";
import { useDispatch, useSelector } from "react-redux";
import {
  createQuestion,
  questionSelectors,
} from "../../../application/reducers/questionSlice";

const useStyles = makeStyles((theme) => ({
  root: {
    padding: "2rem",
  },
  heading: {
    fontSize: "1.5rem",
    marginBottom: "2rem",
  },
  form: {
    display: "flex",
    flexDirection: "column",
    width: "100%",
    rowGap: "1.5rem",
  },
  formItem: {
    display: "flex",
    flexDirection: "column",
    rowGap: "0.35rem",
  },
}));

const GrayTypography = styled(Typography)({
  color: "#5d5d5d",
});

const FormLabel = styled(MuiFormLabel)({
  fontSize: "0.95rem",
});

const DIFFICULTY = {
  EASY: "EASY",
  MEDIUM: "MEDIUM",
  HARD: "HARD",
};

const initialValues = {
  subject: null,
  topic: null,
  subtopic: null,
  questionTitle: "",
  questionType: DIFFICULTY.MEDIUM,
  options: [
    {
      option: "",
      isCorrect: true,
    },
    {
      option: "",
      isCorrect: false,
    },
    {
      option: "",
      isCorrect: false,
    },
    {
      option: "",
      isCorrect: false,
    },
  ],
  explaination: "",
};
const validationSchema = yup.object({
  subject: yup.string().nullable().required().label("Subject"),
  topic: yup.string().nullable().required().label("Topic"),
  subtopic: yup.string().nullable().required().label("Sub-Topic"),
  questionTitle: yup.string().required().label("Question Title"),
  questionType: yup.string().required().label("Difficulty"),
  options: yup.array().of(
    yup.object({
      option: yup.string().required().label("Option"),
      isCorrect: yup.boolean().required().default(false),
    })
  ),
  explaination: yup.string().required().label("Explaination"),
});

export default function AddMCQ() {
  const classes = useStyles();
  const dispatch = useDispatch();

  const { loading } = useSelector(questionSelectors.getQuestionUi.form);

  const onSubmit = async (values, { resetForm }) => {
    console.log(values, "<<<<<values");
    return null;
    const result = await dispatch(createQuestion({ questionData: values }));

    if (result.type === "question/createQuestion/fulfilled") {
      resetForm();
    }
  };

  const handleOptionChange = ({
    newValue,
    i,
    name,
    setFieldValue,
    options,
  }) => {
    setFieldValue(name, newValue);

    newValue &&
      options.forEach((option, optionI) => {
        const optionName = `options.${optionI}.isCorrect`;

        // if not the option that we changed and is checked then uncheckit
        if (optionName !== name && option?.isCorrect) {
          setFieldValue(optionName, false);
        }
      });
  };

  return (
    <Container className={classes.root} component={Paper}>
      <Typography variant="h3" className={classes.heading}>
        Add Multiple Choice Questions
      </Typography>

      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        enableReinitialize
        onSubmit={onSubmit}
      >
        {({
          values,
          errors,
          touched,
          handleChange,
          handleSubmit,
          setFieldValue,
        }) => (
          <div className={classes.form}>
            <div className={classes.formItem}>
              <GrayTypography>Subject</GrayTypography>
              <SubjectAutocomplete
                name="subject"
                error={Boolean(touched.subject && errors.subject)}
                helperText={touched.subject && errors.subject}
              />
            </div>
            {values.subject && (
              <div className={classes.formItem}>
                <GrayTypography>Topic</GrayTypography>
                <TopicAutocomplete
                  name="topic"
                  error={Boolean(touched.topic && errors.topic)}
                  helperText={touched.topic && errors.topic}
                  subjectId={values.subject}
                />
              </div>
            )}
            {values.topic && (
              <div className={classes.formItem}>
                <GrayTypography>Sub-Topic</GrayTypography>
                <SubTopicAutocomplete
                  name="subtopic"
                  error={Boolean(touched.subtopic && errors.subtopic)}
                  helperText={touched.subtopic && errors.subtopic}
                  topicId={values.topic}
                />
              </div>
            )}
            <div className={classes.formItem}>
              <FormControl component="fieldset" style={{ marginTop: "0.5rem" }}>
                <GrayTypography>Difficulty</GrayTypography>
                <RadioGroup
                  style={{ columnGap: "2rem" }}
                  row
                  aria-label="question type"
                  value={values.questionType}
                  name="questionType"
                  onChange={handleChange}
                >
                  <FormControlLabel
                    value={DIFFICULTY.EASY}
                    control={<Radio color="primary" />}
                    label="Easy"
                  />
                  <FormControlLabel
                    value={DIFFICULTY.MEDIUM}
                    control={<Radio color="primary" />}
                    label="Medium"
                  />
                  <FormControlLabel
                    value={DIFFICULTY.HARD}
                    control={<Radio color="primary" />}
                    label="Hard"
                  />
                </RadioGroup>
              </FormControl>
            </div>
            <div
              className={classes.formItem}
              style={{
                border: "1px solid 	#C0C0C0",
                borderRadius: "10px",
                padding: "10px",
              }}
            >
              <GrayTypography>Question</GrayTypography>
              <DraftEditor
                placeholder="Enter question here..."
                initialValue={values.questionTitle}
                name="questionTitle"
                setFieldValue={setFieldValue}
                error={touched.questionTitle && errors.questionTitle}
              />
            </div>

            <div className={classes.formItem}>
              <GrayTypography>Options</GrayTypography>
              {["", "", "", ""].map((option, i) => (
                <Box display="flex" alignItems="center" ml={"-10px"} key={i}>
                  <Tooltip
                    title={
                      values.options[i]?.isCorrect
                        ? "Correct Option"
                        : "Incorrect Option"
                    }
                  >
                    <Checkbox
                      color="primary"
                      name={`options.${i}.isCorrect`}
                      checked={values.options[i]?.isCorrect}
                      onChange={(e) =>
                        handleOptionChange({
                          newValue: e.target.checked,
                          i,
                          name: `options.${i}.isCorrect`,
                          setFieldValue,
                          options: values.options,
                        })
                      }
                    />
                  </Tooltip>
                  <span
                    style={{
                      border: "1px solid 	#C0C0C0",
                      borderRadius: "10px",
                      padding: "10px",
                    }}
                  >
                    <DraftEditor
                      placeholder="Enter option here..."
                      initialValue={values.options[i]?.option}
                      name={`options.${i}.option`}
                      setFieldValue={setFieldValue}
                      error={
                        touched?.options?.[i]?.option &&
                        errors?.options?.[i]?.option
                      }
                    />
                  </span>
                </Box>
              ))}
            </div>

            <div
              className={classes.formItem}
              style={{
                border: "1px solid 	#C0C0C0",
                borderRadius: "10px",
                padding: "10px",
              }}
            >
              <GrayTypography>Explaination</GrayTypography>

              <DraftEditor
                placeholder="Enter explaination about question's answer here..."
                initialValue={values.explaination}
                name="explaination"
                setFieldValue={setFieldValue}
                error={touched.explaination && errors.explaination}
              />
            </div>

            <Button
              disabled={loading}
              onClick={handleSubmit}
              variant="contained"
            >
              {loading ? (
                <CircularProgress size="1.4rem" thickness={5} />
              ) : (
                "Submit"
              )}
            </Button>
          </div>
        )}
      </Formik>
    </Container>
  );
}
