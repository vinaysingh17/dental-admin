import React from "react";

const ViewQuestion = () => {
  // Axios All
  // Question
  // Subject
  // Topic
  // Sub Topic
  return <div>Question Main Page</div>;
};

export default ViewQuestion;
